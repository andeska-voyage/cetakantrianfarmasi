<?php
include('conf/koneksi.php');
$id=$_POST['no_rawat'];
$id_reg=$_POST['no_reg'];
$nama=$_POST['nm_pasien'];
// $sql1 = $conect->query("select RIGHT(resep_obat.no_resep,4) as no_reg,pasien.nm_pasien,resep_obat.no_rawat,dokter.nm_dokter,tgl_peresepan,resep_obat.status from resep_obat inner join reg_periksa inner join pasien inner join dokter on resep_obat.no_rawat=reg_periksa.no_rawat and resep_obat.kd_dokter=dokter.kd_dokter and reg_periksa.no_rkm_medis=pasien.no_rkm_medis where resep_obat.tgl_peresepan = current_date() and no_reg='$id_reg'");
// $data1 = mysqli_fetch_array($sql1);
/* contoh text */       
/* tulis dan buka koneksi ke printer */   

// $printer = printer_open("Microsoft Print to PDF");  
/* write the text to the print job */  
// printer_write($printer, $text);   
/* close the connection */ 
// printer_close($printer);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<style type="text/css">
		* {
		    font-size: 12px;
		    font-family: 'Times New Roman';
		}

		td,
		th,
		tr,
		table {
		    border-top: 1px solid black;
		    border-collapse: collapse;
		}

		td.description,
		th.description {
		    width: 75px;
		    max-width: 75px;
		}

		td.quantity,
		th.quantity {
		    width: 40px;
		    max-width: 40px;
		    word-break: break-all;
		}

		td.price,
		th.price {
		    width: 40px;
		    max-width: 40px;
		    word-break: break-all;
		}

		.centered {
		    text-align: center;
		    align-content: center;
		}

		.ticket {
		    width: 155px;
		    max-width: 155px;
		}

		img {
		    max-width: inherit;
		    width: inherit;
		}

		@media print {
		    .hidden-print,
		    .hidden-print * {
		        display: none !important;
		    }
		}
	</style>
	<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
</head>
<body>
		<div class="ticket" style="text-align:center;">
            <img src="assets/img/logo.png" alt="Logo">
            <p class="centered"><b>Antrian Farmasi Untuk :</b>
                <!-- <u><br>RSIA Restu Ibu</u> -->
            </p>
            <p><?php echo $nama;?></p>
            <table align="center">
                <thead>
                    <tr>
                        <th class="description">Nomor Antri :</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="description" class="justify-content-center"><h1><?php echo $id_reg; ?></h1></td>
                    </tr>
                </tbody>
            </table>
            <p class="centered">Terima Kasih Telah Berobat
            <br><?php echo date("Y-m-d h:i:s"); ?></p>
        </div>
<script src="script.js"></script>
<script type="text/javascript">
	window.print();
 	setTimeout(window.close, 6);
</script>
</body>
</html>
