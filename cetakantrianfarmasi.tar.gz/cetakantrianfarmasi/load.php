<?php
include "conf/koneksi.php";
$sql_cari_data_antrian="select * from ex";
// current_date()
$sql_jumlah = $conect->query($sql_cari_data_antrian);
$cek_row = mysqli_num_rows($sql_jumlah);
?>

      <tbody>
        <?php
          // $poli="'IGDK','U0001','U0002','U0037','U0038'";
              $sql = $conect->query($sql_cari_data_antrian);
              while ($data=$sql->fetch_assoc()) {                           
          ?>
          <tr>
            <td><?php echo $data['no_reg'];?></td>
            <td><?php echo $data['nm_pasien'];?></td>
            <td><?php echo $data['no_rawat'];?></td>
            <td><?php echo $data['nm_dokter'];?></td>
            <td style="text-align:center;width: auto;">
              <form method="post" action="cetak_langsung.php" target="_blank">
                  <input type="hidden" name="no_rawat" value="<?php echo $data['no_rawat'];?>"><br/>
                  <input type="hidden" name="no_reg" value="<?php echo $data['no_reg'];?>"><br/>
                  <input type="hidden" name="nm_pasien" value="<?php echo $data['nm_pasien'];?>"><br/>
                  <button type="submit" class="btn btn-secondary btn-icon-split" style="position: relative; top: -40px;">
                    <span class="icon text-white-50">
                      <i class="fas fa-print"></i>
                    </span>
                    <span class="text">Cetak Antrian</span>
                  </button>
              </form>
            </td>
          </tr>
          <?php
            }
          ?>
      </tbody>